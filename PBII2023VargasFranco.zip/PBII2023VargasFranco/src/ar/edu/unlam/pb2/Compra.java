package ar.edu.unlam.pb2;

public class Compra {
	
	private Double importeCompra;

	public Compra(Juridica comercioEncontrado, Double importeCompra) {
		this.importeCompra = importeCompra;
	}

}
