package ar.edu.unlam.pb2;

import java.util.List;

public class MedioDePago {
	

}
